package it.model;

public class Admin extends user
{

}
